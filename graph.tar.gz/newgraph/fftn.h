#ifndef FFTN_H
#define FFTN_H

extern void fourn(double data[],int nn[],int ndim,int isign);

#endif

#ifndef MYRAND_H
#define MYRAND_H

double myrand(double);
double ran3(int *idum);

#endif
